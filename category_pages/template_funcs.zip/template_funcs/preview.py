# category_pages/template_funcs/preview.py

import streamlit as st
import os
import base64

def render_documents(folder_name: str):
    """
    📄 업로드된 PDF 다운로드 및 미리보기 UI
    uploaded_pdfs/<folder_name>/<folder_name>.pdf 경로를 사용합니다.
    """
    pdf_path = os.path.join("uploaded_pdfs", folder_name, f"{folder_name}.pdf")

    if not os.path.exists(pdf_path):
        st.warning("⚠️ PDF 원본 파일이 존재하지 않습니다.")
        return

    key = f"toggle_{folder_name}"
    if key not in st.session_state:
        st.session_state[key] = False

    if st.button(f"📄 {folder_name}", key=f"btn_{folder_name}"):
        st.session_state[key] = not st.session_state[key]

    if st.session_state[key]:
        st.markdown("---")
        st.subheader(f"📖 미리보기: {folder_name}")

        with open(pdf_path, "rb") as f:
            data = f.read()

        st.download_button(
            "⬇️ PDF 다운로드",
            data=data,
            file_name=f"{folder_name}.pdf",
            mime="application/pdf"
        )

        b64 = base64.b64encode(data).decode("utf-8")
        iframe = f"""
            <iframe src="data:application/pdf;base64,{b64}"
                    width="100%" height="800px"
                    style="border:1px solid #ccc; border-radius:8px;">
            </iframe>
        """
        st.markdown(iframe, unsafe_allow_html=True)
