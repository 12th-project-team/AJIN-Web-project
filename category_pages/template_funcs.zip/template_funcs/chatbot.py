# category_pages/template_funcs/chatbot.py

import os
import streamlit as st
from langchain_community.embeddings import OpenAIEmbeddings
from langchain_community.chat_models import ChatOpenAI
from langchain.chains import RetrievalQA
from langchain.prompts import PromptTemplate
from vectorstore_utils import list_chroma_files

CHAT_STYLE = """
<style>
.chat-container {
  max-width: 700px;
  margin: 0 auto 30px;
  font-family: "Segoe UI", Tahoma, Geneva, Verdana, sans-serif;
}
.bubble {
  padding: 12px 18px;
  border-radius: 20px;
  margin: 8px 0;
  max-width: 80%;
  word-wrap: break-word;
  font-size: 16px;
  line-height: 1.4;
  display: inline-block;
  box-shadow: 0 2px 5px rgba(0,0,0,0.1);
}
.user { background-color: #DCF8C6; float: right; clear: both; text-align: right; }
.bot  { background-color: #F1F0F0; float: left; clear: both; text-align: left; }
.clearfix::after { content: ""; clear: both; display: table; }
h2 { font-weight: 700; font-size: 1.8rem; margin-bottom: 20px; color: #333; }
.selectbox-label { font-weight: 600; margin-bottom: 5px; color: #444; }
</style>
"""

custom_prompt = PromptTemplate(
    input_variables=["context", "question"],
    template="""
아래 문서 내용을 참고하여 질문에 친절하고 내용중심적으로 답변해 주세요.

문서 내용:
{context}

질문:
{question}

답변:
"""
)

def render_chat_history(chat_history):
    st.markdown(CHAT_STYLE, unsafe_allow_html=True)
    st.markdown('<div class="chat-container">', unsafe_allow_html=True)
    for question, answer in chat_history:
        st.markdown(f'<div class="clearfix"><div class="bubble user">👤 {question}</div></div>', unsafe_allow_html=True)
        st.markdown(f'<div class="clearfix"><div class="bubble bot">🤖 {answer}</div></div>', unsafe_allow_html=True)
    st.markdown('</div>', unsafe_allow_html=True)

def render(category_name: str):
    """
    💬 챗봇 탭: category_name 문서 기반 챗봇을 띄웁니다.
    """
    st.header(f"💬 {category_name} 문서 기반 챗봇")

    base_path = os.path.join("chroma_db", category_name)
    subfolders = list_chroma_files(category_name)
    if not subfolders:
        st.info("❗ 저장된 문서가 없습니다.")
        return

    if "chat_history" not in st.session_state:
        st.session_state.chat_history = []

    st.markdown('<label class="selectbox-label">📂 질문할 문서를 선택하세요</label>', unsafe_allow_html=True)
    selected_doc = st.selectbox("", subfolders, key=f"chat_doc_{category_name}")

    if st.session_state.chat_history:
        render_chat_history(st.session_state.chat_history)

    def handle_submit():
        q = st.session_state[f"chat_input_{category_name}"]
        if not q.strip():
            st.warning("❗ 질문을 입력해주세요.")
            return

        with st.spinner("⏳ 답변 생성 중..."):
            vectordb = Chroma(
                persist_directory=os.path.join(base_path, selected_doc),
                embedding_function=OpenAIEmbeddings()
            )
            retriever = vectordb.as_retriever(search_type="similarity", k=3)
            llm = ChatOpenAI(temperature=0, model_name="gpt-3.5-turbo")
            qa = RetrievalQA.from_chain_type(
                llm=llm,
                chain_type="stuff",
                retriever=retriever,
                chain_type_kwargs={"prompt": custom_prompt}
            )
            answer = qa.run(q)
            st.session_state.chat_history.append((q, answer))

        st.session_state[f"chat_input_{category_name}"] = ""

    st.text_input(
        "❓ 질문을 입력하세요",
        key=f"chat_input_{category_name}",
        on_change=handle_submit,
        placeholder="질문을 입력하고 Enter"
    )
