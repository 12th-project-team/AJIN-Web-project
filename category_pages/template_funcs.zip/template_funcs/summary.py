# category_pages/template_funcs/summary.py

import streamlit as st

def render(category_name: str):
    """
    📌 요약 탭: category_name에 대한 요약을 보여줍니다.
    """
    st.info(f"📌 {category_name} - 요약 탭입니다.")
