# category_pages/template_funcs/exam.py

import streamlit as st

def render(category_name: str):
    """
    📄 기출문제 탭: category_name에 대한 기출문제 리스트를 보여줍니다.
    """
    st.info(f"📄 {category_name} - 기출문제 탭입니다.")
