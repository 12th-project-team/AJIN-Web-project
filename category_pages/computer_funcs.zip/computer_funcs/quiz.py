import streamlit as st
from langchain_openai import ChatOpenAI
from vectorstore_utils import load_chroma_vectorstore
import os, re

CATEGORY_NAME = "컴퓨터활용능력"

def build_context_from_docs(docs, max_length=8000):
    context = ""
    for doc in docs:
        if len(context) + len(doc.page_content) > max_length:
            break
        context += doc.page_content + "\n"
    return context

def generate_quiz(llm, context, topic):
    prompt = f"""
너는 컴퓨터활용능력 자격시험의 객관식 문제 출제자야.
'{topic}'와 직접적으로 관련된 내용만 사용해 10문제 출제해줘.
각 문제는 보기 4개, 정답 번호, 해설을 포함해야 해.
형식:

[중략]

{context}
"""
    return llm.invoke(prompt)

def parse_quiz(text: str):
    items = []
    for m in re.finditer(r"문제\s*\d+\.?([\s\S]*?)(?=문제\s*\d+\.?|$)", text):
        block = m.group(1).strip()
        lines = [l.strip() for l in block.splitlines() if l.strip()]
        if not lines:
            continue
        question = lines[0]
        choices = lines[1:5]
        while len(choices) < 4:
            choices.append("보기 없음")
        answer = None
        for ln in lines:
            if ans := re.search(r"정답[:\s]*([1-4])", ln):
                answer = int(ans.group(1))
                break
        explanation = ""
        heil = re.search(r"해설[:\-]\s*(.+)", block, re.DOTALL)
        if heil:
            explanation = heil.group(1).strip()
        items.append({
            "question": question,
            "choices": choices,
            "answer": answer,
            "explanation": explanation
        })
    return items

def render(category_name: str):
    st.header(f"📝 {category_name} - 객관식 퀴즈 풀기")

    base_path = os.path.join("chroma_db", category_name)
    if not os.path.exists(base_path):
        st.info("❗ 저장된 문서가 없습니다. 먼저 PDF를 업로드하세요.")
        return

    subfolders = [
        d for d in os.listdir(base_path)
        if os.path.isdir(os.path.join(base_path, d))
    ]
    if not subfolders:
        st.info("❗ 저장된 문서가 없습니다.")
        return

    if "quiz_items" not in st.session_state:
        selected_doc = st.selectbox("퀴즈를 생성할 문서를 선택하세요", subfolders)
        query = st.text_input("퀴즈 생성 주제를 입력하세요:", placeholder="예) 함수, IF, 논리연산자 등")
        if st.button("퀴즈 생성 및 풀기") and query:
            try:
                vectordb = load_chroma_vectorstore(CATEGORY_NAME, selected_doc)
                retriever = vectordb.as_retriever(search_kwargs={"k": 15})
                llm = ChatOpenAI(model_name="gpt-3.5-turbo", temperature=0.3)
                docs = retriever.get_relevant_documents(query)
                context = build_context_from_docs(docs)
                with st.spinner("📝 퀴즈를 생성 중입니다..."):
                    response = generate_quiz(llm, context, query)
                    quiz_list = parse_quiz(response.content if hasattr(response, "content") else response)
                if not quiz_list:
                    st.error("❗ 파싱된 문제가 없습니다. LLM 원문을 확인하세요.")
                    st.text_area("LLM 원문", response.content if hasattr(response, "content") else response, height=200)
                    return
                st.session_state.quiz_items = quiz_list
                st.session_state.answers = {}
                st.session_state.incorrect = []
                st.session_state.submitted = False
            except Exception as e:
                st.error(f"퀴즈 생성 중 오류 발생: {e}")
                return

    if "quiz_items" not in st.session_state:
        return

    submitted = st.session_state.get("submitted", False)
    if not submitted:
        with st.form(f"quiz_form_{category_name}"):
            for idx, q in enumerate(st.session_state.quiz_items):
                st.markdown(f"**Q{idx+1}. {q['question']}**")
                choice = st.radio(
                    label="선택지",
                    options=q["choices"],
                    key=f"quiz_choice_{category_name}_{idx}",
                    label_visibility="collapsed"
                )
                st.session_state.answers[idx] = q["choices"].index(choice) + 1
            submitted_button = st.form_submit_button("제출")

        if submitted_button:
            score = 0
            incorrect = []
            for idx, q in enumerate(st.session_state.quiz_items):
                if st.session_state.answers.get(idx) == q["answer"]:
                    score += 1
                else:
                    incorrect.append(idx)
            st.session_state.score = score
            st.session_state.incorrect = incorrect
            st.session_state.submitted = True

    if st.session_state.get("submitted", False):
        total = len(st.session_state.quiz_items)
        st.success(f"총 {total}문제 중 {st.session_state.score}문제 정답! 점수: {int(st.session_state.score / total * 100)}점")

        if st.session_state.incorrect:
            with st.expander("❌ 틀린 문제 해설 보기"):
                for idx in st.session_state.incorrect:
                    q = st.session_state.quiz_items[idx]
                    st.markdown(f"- **Q{idx+1}. {q['question']}**")
                    st.markdown(f"  - 정답: {q['choices'][q['answer']-1]}")
                    st.markdown(f"  - 해설: {q['explanation']}")

            if st.button("🔁 오답 다시 풀기"):
                st.session_state.quiz_items = [st.session_state.quiz_items[i] for i in st.session_state.incorrect]
                st.session_state.answers = {}
                st.session_state.incorrect = []
                st.session_state.submitted = False
                st.rerun()

        if st.button("🔄 새 퀴즈 생성"):
            for key in ["quiz_items", "answers", "submitted", "score", "incorrect"]:
                if key in st.session_state:
                    del st.session_state[key]
            st.rerun()
